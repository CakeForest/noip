#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <cmath>

const int maxn = 5010,inf = 1e8;

using namespace std;
int n, x[maxn], y[maxn],vis[maxn];
double d[maxn],ans,temp;

double jisuan(int x1, int y1, int x2, int y2)
{
    return sqrt((double)(x1 - x2) * (x1 - x2) + (double)(y1 - y2) * (y1 - y2));
}

int main()
{
		freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);

    scanf("%d", &n);
    for (int i = 1; i <= n; i++)
        scanf("%d%d", &x[i], &y[i]);
    for (int i = 1; i <= n; i++)
        d[i] = inf;
    d[1] = 0;
    int flag;
    for (int i = 1; i <= n; i++)
    {
        temp = inf;
        for (int j = 1; j <= n; j++)
            if (!vis[j] && d[j] < temp)
            {
                temp = d[j];
                flag = j;
            }
        if (temp == inf)
            break;
        vis[flag] = 1;
        ans += temp;
        for (int j = 1; j <= n; j++)
            if (!vis[j])
            {
                double s = jisuan(x[flag], y[flag], x[j], y[j]);
                if (s < d[j])
                    d[j] = s;
            }
                
    }
    printf("%.2lf\n", ans);

    return 0;
}
