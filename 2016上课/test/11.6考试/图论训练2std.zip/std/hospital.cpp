#include<iostream>

#include<cstdio>

#include<cstring>

using namespace std;

int n,g[1001][1001],a[1001];

void init()

{

int j,k,l;

cin>>n;

for(int i=1;i<=n;i++)

for(int j=1;j<=n;j++)

  g[i][j]=100000000;

for(int i=1;i<=n;i++)

{

g[i][i]=0;

cin>>j>>k>>l;

a[i]=j;

if(k!=0) g[i][k]=g[k][i]=1;

if(l!=0) g[i][l]=g[l][i]=1;

}

}

int floyd()

{

     for(int k=1;k<=n;k++)

     for(int i=1;i<=n;i++)

     if(k!=i)

     for(int j=1;j<=n;j++)

     {

     	if((i!=j)&&(k!=j)&&(g[i][k]+g[k][j]<g[i][j]))

     	{

     	    g[i][j]=g[i][k]+g[k][j];

     	    g[j][i]=g[i][j];

     	}

     }

     int mi=10000000,s;

     for(int i=1;i<=n;i++)

     {

     	s=0;

for(int j=1;j<=n;j++)

     	{

     	s+=g[i][j]*a[j];

     	}

     	if(mi>s) mi=s; 

     }

     printf("%d",mi);

}

int main()

{
	freopen("hospital.in","r",stdin);
	freopen("hospital.out","w",stdout);

init();

floyd();

}
