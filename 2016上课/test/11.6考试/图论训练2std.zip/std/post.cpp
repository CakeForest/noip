#include<queue>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define ll long long
using namespace std;
int f[1010][1010];
int a[100010],nxt[100010],p[1010],val[100010],tot;
int n,m;
ll ans,dis[1010];
inline void add(int x,int y,int v)
{
	tot++; a[tot]=y; nxt[tot]=p[x]; p[x]=tot; val[tot]=v;
}
inline void spfa()
{
	queue<int>que;
	memset(dis,127/3,sizeof(dis));
	dis[1]=0; que.push(1);
	while(!que.empty())
	 {
	 	int u=que.front(); que.pop();
	 	int v=p[u];
	 	while(v!=-1)
	 	 {
	 	 	if(dis[a[v]]>dis[u]+(ll)val[v])
	 	 	 {
	 	 	 	dis[a[v]]=dis[u]+(ll)val[v];
	 	 	 	que.push(a[v]);
			   }
			v=nxt[v];
		  }
	 }
	for(int i=2;i<=n;++i) ans+=dis[i];
	return;
}
int main()
{
	freopen("post.in","r",stdin);
	freopen("post.out","w",stdout);
	int i,j;
	memset(f,127,sizeof(f));
	memset(p,-1,sizeof(p));
	memset(nxt,-1,sizeof(nxt));
	scanf("%d%d",&n,&m);
	for(i=1;i<=m;++i)
	  {
	  	int x,y,z;
	  	scanf("%d%d%d",&x,&y,&z);
	  	if(f[x][y]>z) f[x][y]=z;
	  	add(x,y,z);
	  }
	spfa(); tot=0;
	memset(p,-1,sizeof(p));
	memset(nxt,-1,sizeof(nxt));
	for(i=1;i<=n;++i)
	 for(j=1;j<=n;++j)
	  if(i!=j&&f[i][j]!=f[0][0])
	   add(j,i,f[i][j]);
	spfa();
	printf("%lld\n",ans);
	return 0;
}
