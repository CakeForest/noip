#include<stdio.h> 
#include<stdlib.h> 
#include<string.h> 
  
int main() 
{ 
    int n,m; 
    int x,y; 
    long long k[50][50]={0}; 
    long long px,py;//�ֱ�Ϊ��Ӧ��������һ�������һ��  
    scanf("%d %d %d %d",&n,&m,&x,&y); // n,mĿ�ĵ����� x,y��������  
    k[x][y]=-1; 
    k[x-2][y-1]=-1; 
    k[x-1][y-2]=-1; 
    k[x+1][y-2]=-1; 
    k[x+2][y-1]=-1; 
    k[x-2][y+1]=-1; 
    k[x-1][y+2]=-1; 
    k[x+1][y+2]=-1; 
    k[x+2][y+1]=-1; 
      
    for(int j=0;j<=m;j++)//���� 
        for(int i=0;i<=n;i++)//���� 
        { 
            if(k[i][j]!=-1) 
            { 
                if(i==0||k[i-1][j]==-1) 
                    px=0; 
                else
                    px=k[i-1][j]; 
                if(j==0||k[i][j-1]==-1) 
                    py=0; 
                else
                    py=k[i][j-1]; 
            k[i][j]=i+j==0?1:px+py; 
            } 
              
        }  
      
      
    printf("%lld",k[n][m]); 
  
      
    return 0; 
} 
