#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main()
{
	int pa[30],pp[30];//����(a) (p)    people=pa+pp
	int upa[30],upp[30];//�ϳ�����  people=upa+upp 
	int p;//δ֪��p 
	int a,n,m,x;
	scanf("%d %d %d %d",&a,&n,&m,&x);
	
	pa[1]=1;pp[1]=0;
	upa[1]=1;upp[1]=0;
	pa[2]=1;pp[2]=0;
	upa[2]=0;upp[2]=1;
	
	for(int i=3;i<=n-1;i++)
	{
		pa[i]=pa[i-1]+upa[i-2];
		pp[i]=pp[i-1]+upp[i-2];
		upa[i]=upa[i-2]+upa[i-1];
		upp[i]=upp[i-2]+upp[i-1];
	}
	
	p=(m-pa[n-1]*a)/pp[n-1];
	
	printf("%d",pa[x]*a+pp[x]*p);
	 

	
	return 0;
}
