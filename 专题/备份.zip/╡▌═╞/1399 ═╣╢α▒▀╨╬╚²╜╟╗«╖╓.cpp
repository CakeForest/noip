#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main()
{
	int n;
	long long k[100];
	scanf("%d",&n);
	
	k[0]=1;
	k[1]=1;
	for(int i=2;i<=n-2;i++)
	{
		k[i]=k[i-1]*(4*i-2)/(i+1);
	}
	printf("%lld",k[n-2]);
	
	return 0;
}
