#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main()
{
	int n;
	scanf("%d",&n);
	int k[2000];
	k[1]=1;
	k[2]=2;
	
	for(int i=3;i<=n;i++)//3~n 
	{
		for(int j=1;j<=i/2;j++)
			k[i]+=k[j];
		k[i]+=1;
	}
	
	printf("%d",k[n]);
	
	return 0;
}
