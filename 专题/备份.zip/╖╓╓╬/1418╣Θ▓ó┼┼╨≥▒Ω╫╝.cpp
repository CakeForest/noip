#include<stdio.h> 
int a[100020],q[100020],n;
void merge(int l,int mid,int r)//��������������һ������ 
{
	int i=l,j=mid+1,now=l;
	while(i<=mid&&j<=r)
		if(a[i]<a[j])
			q[now++]=a[i++];
		else
			q[now++]=a[j++];
	if(i<=mid)
		while(i<=mid) q[now++]=a[i++];
	else if(j<=r)
		while(j<=r) q[now++]=a[j++];
	for(int now=l;now<=r;now++)
		a[now]=q[now];
}
void mergesort(int l,int r)
{
	if(l>=r) return;
	int mid=(l+r)/2;
	mergesort(l,mid);//���ֳ��������� 
	mergesort(mid+1,r);
	merge(l,mid,r);
}
int main() 
{ 
//  freopen("in.txt","r",stdin); 
    scanf("%d",&n); 
    for(int i=1;i<=n;i++) 
        scanf("%d",&a[i]); 
    mergesort(1,n); 
      
    for(int i=1;i<=n;i++) 
    { 
        printf("%d",a[i]); 
        if(i!=n) 
            printf("\n"); 
    } 
      
    return 0; 
} 

