#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int a[11000000];
int search(int l,int r,int aim)
{
	if(l>r)
		return -1;
	if(a[(l+r)/2]==aim)
		return (l+r)/2;
	if(a[l]==aim||a[r]==aim)
		return a[l]==aim?l:r;
	return a[(l+r)/2]>aim?search(l,(l+r)/2-1,aim):search((l+r)/2+1,r,aim);
}

int main()
{
	int ask[10000];
	int n,m;
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(int i=1;i<=m;i++)
		scanf("%d",&ask[i]);
	for(int i=1;i<=m;i++)
	{
		if(n!=1) printf("%d",search(1,n,ask[i]));
		else if(ask[1]==a[1]) printf("1");
		else printf("-1"); 
		if(i!=m) 
			printf("\n");
	}
	return 0;
}
