#include<stdio.h>
#include<stdlib.h>
#include<string.h>

void hnt(int n,char a,char b,char c)
{
	if(n==1)
	{
		printf("%d %c->%c\n",n,a,b); return;
	}
	if(n>1)
	{
		hnt(n-1,a,c,b);
		printf("%d %c->%c\n",n,a,b);
		hnt(n-1,c,b,a);
		return;
	}
		
}

int main()
{
	int n;
	scanf("%d",&n);
	hnt(n,'A','B','C');
	
	return 0;
}
