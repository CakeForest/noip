#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int n,m;
int a[100];
int fun(int m,int n)
{
	if(n==0)
		return 0;
	for(int i=1;i<=n;i++)
	{
		if(a[i]==m)
			return 1;
	}
		
	return fun(m-a[n],n-1)||fun(m,n-1);
	
}
int main()
{
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	
	if(fun(m,n-1)||fun(m-a[n],n-1))
		printf("YES");
	else
		printf("NO");
	

		
	return 0;
}
