#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int step(int n)
{
	if(n==1)
		return 1;
	else if(n==2)
		return 2;
	else
		return step(n-2)+step(n-1);
}
int main()
{
	int n;
	scanf("%d",&n);
	printf("%d",step(n));

	
	return 0;
}
