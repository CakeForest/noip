#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int a[10000];
int input;int step=0;
void print()
{
	printf("step %d:",step);
	for(int i=1;i<=2*input+2;i++)
	{
		switch(a[i])
		{
			case 1:printf("o");break;
			case 2:printf("*");break;
			case -1:printf("_");break;
		}
	}
	printf("\n");
	step++;
}

void move(int n)
{
	if(n>4)
	{
		a[2*n+1]=a[n];
		a[2*n+2]=a[n+1];
		a[n]=-1; a[n+1]=-1;
		print();//step1
		
		a[n]=a[2*n-1];
		a[n+1]=a[2*n];
		a[2*n-1]=-1; a[2*n]=-1;
		print();//step2
		
		move(n-1);
		return;
	}
	
	a[9]=a[4]; a[10]=a[5];
	a[4]=-1; a[5]=-1;
	print();//step7
	
	a[4]=a[8]; a[5]=a[9];
	a[8]=-1; a[9]=-1;
	print();//step8
	
	a[8]=a[2]; a[9]=a[3];
	a[2]=-1; a[3]=-1;
	print();//step9
	
	a[2]=a[7]; a[3]=a[8];
	a[7]=-1; a[8]=-1;
	print();//step10
	
	a[7]=a[1]; a[8]=a[2];
	a[1]=-1; a[2]=-1;
	print();//step11;
	return;
}




int main()
{
	scanf("%d",&input);
	for(int i=1;i<=input;i++)
	{
		a[i]=1;//������
		a[i+input]=2;//������
	}
	a[2*input+1]=-1;
	a[2*input+2]=-1;
	print();
    move(input);
	return 0;
}
