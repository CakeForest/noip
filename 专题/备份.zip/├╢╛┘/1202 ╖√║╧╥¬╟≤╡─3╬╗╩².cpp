#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main()
{
	for(int i=123;i<=333;i++)
	{
		int a[10];
		a[1]=i/100;
		a[2]=i/10%10;
		a[3]=i%10;
		a[4]=2*i/100;
		a[5]=2*i/10%10;
		a[6]=2*i%10;
		a[7]=3*i/100;
		a[8]=3*i/10%10;
		a[9]=3*i%10;
		bool truth=1;
		for(int x=1;x<=9;x++)
		{
			for(int y=1;y<=9;y++)
			{
				if(a[x]==a[y]&&x!=y)
					truth=0;		
			}
			if(a[x]==0)
				truth=0;
		}
		if(truth)
			printf("%d %d %d\n",i,2*i,3*i);
	}

	
	return 0;
}
