#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main()
{
	int n;
	int a[30];
	long long ans=-1;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(int num=1;num<=n;num++)//ö��num�������
	{
		for(int i=1;i<=n-num+1;i++)//�ӵ�i������ʼö��
		{
			long long now=1;
			for(int j=i;j<=i+num-1;j++)
				now*=a[j];
			if(now>ans)
				ans=now;
		} 
	} 
	
	printf("%lld",ans==-1?0:ans);
	
	
	return 0;
}
