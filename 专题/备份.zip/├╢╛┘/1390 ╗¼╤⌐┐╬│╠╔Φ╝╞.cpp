#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

int work(int m,int h)
{
	if(m-h>17)
		return (m-(h+17))*(m-(h+17));
	else if(m<h)
		return (m-h)*(m-h);
	else
		return 0;
}

int main()
{
	int n;
	int a[1200];
	scanf("%d",&n);
	int max=0,min=100;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		if(a[i]>max)
			max=a[i];
		if(a[i]<min)
			min=a[i];
	}
	int ans;
	for(int h=min;h<=max;h++)//�о����п��ܵĸ߶�
	{
		int sum=0;
		for(int i=1;i<=n;i++)
			sum+=work(a[i],h);
		if(sum<ans||h==min)
			ans=sum;
	} 
	printf("%d",ans);
	
	return 0;
}
