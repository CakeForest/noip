#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int match[10]={6,2,5,5,4,5,6,3,7,6};
int fun(int n)
{
	if(n==0)
		return match[0];
	else
	{
		int tot=0;
		while(n>=10)
		{
			tot+=match[n%10];
			n/=10;
		}
		tot+=match[n];
		return tot;
	}
}

int main()
{
	int n;
	scanf("%d",&n);
	if(n<=4)
	{
		printf("0");
		return 0;
	}
	int sum=0;
	for(int x=0;x<=1111;x++)
		for(int y=0;y<=1111;y++)
			{
				if(fun(x)+fun(y)+fun(x+y)==n-4)
					sum++;
			}
	printf("%d",sum);
			
	return 0;
}
