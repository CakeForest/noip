#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int judge(int a,int b)
{
	int x[11]={0};
	for(int i=1;i<=5;i++)
	{
		x[a%10]++;
		a/=10;
		x[b%10]++;
		b/=10;
	}
	for(int i=0;i<=9;i++)
	{
		if(x[i]!=1)
			return 0;
	}
	return 1;

}

void pri(int num)
{
	if(num<10000)
		printf("0%d",num);
	else
		printf("%d",num);
}

int main()
{
	int n;
	scanf("%d",&n);
	for(int i=1234;i<=98765;i++)
	{
		if(i*n<=99999&&judge(i*n,i)==1)
		{
			pri(i*n);
			printf("/");
			pri(i);
			printf("=%d\n",n);
		}
	}

	
	return 0;
}
