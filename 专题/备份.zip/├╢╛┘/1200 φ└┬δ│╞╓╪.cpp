#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main()
{
	int g[21];
	int a[21];
	int gram[1200]={0};
	scanf("%d %d %d %d %d %d",&g[1],&g[2],&g[3],&g[5],&g[10],&g[20]);
	for(a[1]=0;a[1]<=g[1];a[1]++)
		for(a[2]=0;a[2]<=g[2];a[2]++)
			for(a[3]=0;a[3]<=g[3];a[3]++)
				for(a[5]=0;a[5]<=g[5];a[5]++)
					for(a[10]=0;a[10]<=g[10];a[10]++)
						for(a[20]=0;a[20]<=g[20];a[20]++)
						{
							int weight=a[1]*1+a[2]*2+a[3]*3+a[5]*5+a[10]*10+a[20]*20
							if(weight>0)
								gram[weight]++;
						}
	int sum=0;
	for(int i=1;i<=1020;i++)
	{
		if(gram[i]>0)
			sum++;
	}
	printf("Total=%d",sum);
	
	return 0;
}
