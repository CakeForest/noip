#include<stdio.h>
#include<stdlib.h>

int main()
{
    int a,b,c,d,e,f,g;
    scanf("%d,%d,%d,%d,%d,%d,%d",&a,&b,&c,&d,&e,&f,&g);
    printf("%d",a+b+c+d+e+f+g);
    system("pause");
    return(0);
}
